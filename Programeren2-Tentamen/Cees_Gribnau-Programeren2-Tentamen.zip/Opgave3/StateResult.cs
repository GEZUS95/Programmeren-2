﻿namespace Opgave3
{
    public class StateResult
    {
        public string StateName;
        public string CandidateName;
        public string PartyName;
        public int CandidateVotes;

    }
}
