﻿namespace Opgave3
{
    public class StateElectors
    {
        public string StateName;
        public int ElectorsCount;
    }
}
