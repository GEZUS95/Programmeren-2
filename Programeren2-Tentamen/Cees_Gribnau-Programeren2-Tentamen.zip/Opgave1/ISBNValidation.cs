﻿namespace Opgave1
{
    public enum ISBNValidation
    {
       InvalidISBN, ValidISBN13
    }
}
