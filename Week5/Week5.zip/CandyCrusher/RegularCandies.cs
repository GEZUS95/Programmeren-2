﻿namespace CandyCrusherLogic
{
    public enum RegularCandies
    {
        JellyBean, Lozenge, LemonDrop, Gum_Square, LollipopHead, Jujube_Cluster
    }
}
