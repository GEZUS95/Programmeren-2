﻿namespace assignment3
{
    enum RegularCandies
    {
        JellyBean, Lozenge, LemonDrop, Gum_Square, LollipopHead, Jujube_Cluster
    }
}
