﻿namespace assignment2
{
    public class Position
    {
        public int row, colum;

        
    }
}
