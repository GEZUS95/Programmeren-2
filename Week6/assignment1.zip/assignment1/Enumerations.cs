﻿namespace assignment1
{
    public enum ChessPieceColor
    {
        Black, White
    }

    public enum ChessPieceType
    {
        Pawn, Rook, Knight, Bishop, King, Queen
    }
}
