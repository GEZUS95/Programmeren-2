﻿namespace assignment1
{
    public class Position
    {
        public int row, col;
        
    }
}
